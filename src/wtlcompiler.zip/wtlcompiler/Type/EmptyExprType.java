package wtlcompiler.Type;

public class EmptyExprType extends Type{
    public EmptyExprType() {
        super("Expr", 0);
    }
}
