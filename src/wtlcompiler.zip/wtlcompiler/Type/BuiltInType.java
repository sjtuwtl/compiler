package wtlcompiler.Type;

public class BuiltInType extends Type{
    public BuiltInType(String name, int size) {
        super(name, size);
    }
}
